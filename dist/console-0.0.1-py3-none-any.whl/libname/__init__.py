from console import log
