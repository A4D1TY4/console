def log(data):
    print(data)